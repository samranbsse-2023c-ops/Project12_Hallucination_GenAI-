
# Hallucination Detection Framework (Simplified)

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        return "Error"
    return a / b

# Test-driven validation
def run_tests():
    assert multiply(3,4) == 12
    assert divide(10,2) == 5
    assert divide(5,0) == "Error"

if __name__ == "__main__":
    run_tests()
    print("All tests passed. No hallucination detected.")
